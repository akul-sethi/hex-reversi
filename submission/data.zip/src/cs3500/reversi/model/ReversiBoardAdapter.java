//package cs3500.reversi.model;
//import cs3500.provider.model.IReversiBoard;
//public class ReversiBoardAdapter extends BasicReversi implements  {
//}
