package cs3500.reversi;

import cs3500.reversi.model.BasicPoint;
import cs3500.reversi.model.GameType;
import cs3500.reversi.model.ReversiCreator;
import cs3500.reversi.model.ReversiModel;
import cs3500.reversi.player.CaptureMaxPlayer;
import cs3500.reversi.player.Player;
import cs3500.reversi.player.SuperStrategyPlayer;
import cs3500.reversi.view.GUIReversiView;
import cs3500.reversi.view.ReversiView;


/**
 * Entry point to a game of Reversi.*/
public final class Reversi {

  /*
  * Actual entry point method.*/
  public static void main(String[] args) {
      Player p1 = new SuperStrategyPlayer("X");
      Player p2 = new CaptureMaxPlayer("O");
      ReversiModel model = ReversiCreator.create(GameType.BASIC, 6, p1, p2);
      model.placePiece(new BasicPoint(2, 0));
    model.placePiece(new BasicPoint(-2, 0));
    model.placePiece(new BasicPoint(-1, 1));
      ReversiView view = new GUIReversiView(model);
      view.setVisible(true);
    }

}

